<?php
session_start();

if(!isset($_SESSION["username"]))
{
	header("location:login.php");
}

?>

<!DOCTYPE html>
<html>
<head>
	<title>Admin Page</title>
</head>
<body>

<h1 style="color:red ;" align="center">THIS IS ADMIN HOME PAGE</h1>
<br>
<br>

<h1>Patient Details</h1>
<div class="card-body">
 <div class="table-responsive">
  <table class="table table-bordered" ; style="color: blue;" ">
  <thead>
    <tr>
      <th scope="col">Patient Name</th>
      <th scope="col">Email</th>
      <th scope="col">Organization</th>
      
    </tr>
  </thead>
  <tbody>
    <?php

    $host="localhost";
    $user="root";
    $password="";
 $db="patient";
  
     
    $con=mysqli_connect($host,$user,$password,$db);

    if($con===false)
{
	die("connection error");
}


     $sql="select user.username,user.email,organization.name 
	 from 
	 user 
	 inner join 
	 organization on user.Organization = organization.organizationID  WHERE user.Role_IDrole='1'; ";
    $query1=mysqli_query($con,$sql);
     //$row=mysqli_fetch_array($query1);
     

    while ($row=mysqli_fetch_array($query1))
    {
    ?>
    <tr>
        
        <td> <?php echo  $row['username'];?>  </td>
        <td> <?php echo $row['email'];?>  </td>
        <td> <?php echo $row['name'];?>  </td>
        

       
    </tr>
    <?php
    }
    ?>
	<tr><button type="button">Add Patient</button></tr>
	<br>
	<br>
  </tbody>
</table>


        </div>

    </div>
	<br>
	<br>
	<h1>Physician Details</h1>
<div class="card-body">
 <div class="table-responsive">
  <table class="table table-bordered" ; style="color: blue;" >
  <thead>
    <tr>
      <th scope="col">Physician Name</th>
      <th scope="col">Email</th>
      <th scope="col">Organization</th>
      
    </tr>
  </thead>
  <tbody>
    <?php

  

     $sql1="select user.username,user.email,organization.name 
	 from 
	 user 
	 inner join 
	 organization on user.Organization = organization.organizationID  WHERE user.Role_IDrole='2'; ";
    $query2=mysqli_query($con,$sql1);
     //$row=mysqli_fetch_array($query1);
     

    while ($row1=mysqli_fetch_array($query2))
    {
    ?>
    <tr>
        
        <td> <?php echo  $row1['username'];?>  </td>
        <td> <?php echo $row1['email'];?>  </td>
        <td> <?php echo $row1['name'];?>  </td>
        

       
    </tr>
    <?php
    }
    ?>
	<tr><button type="button">Add Physician</button></tr>
	<br>
	<br>
  </tbody>
</table>


        </div>

    </div>
	<br>
	<br>
	<h1>Researcher Details</h1>
<div class="card-body">
 <div class="table-responsive">
  <table class="table table-bordered" ; style="color: blue;" ">
  <thead>
    <tr>
      <th scope="col">Researcher Name</th>
      <th scope="col">Email</th>
      <th scope="col">Organization</th>
      
    </tr>
  </thead>
  <tbody>
    <?php

  

     $sql2="select user.username,user.email,organization.name 
	 from 
	 user 
	 inner join 
	 organization on user.Organization = organization.organizationID  WHERE user.Role_IDrole='2'; ";
    $query3=mysqli_query($con,$sql2);
     //$row=mysqli_fetch_array($query1);
     

    while ($row2=mysqli_fetch_array($query3))
    {
    ?>
    <tr>
        
        <td> <?php echo  $row2['username'];?>  </td>
        <td> <?php echo $row2['email'];?>  </td>
        <td> <?php echo $row2['name'];?>  </td>
        

       
    </tr>
    <?php
    }
    ?>
	<tr><button type="button">Add Physician</button></tr>
	<br>
	<br>
  </tbody>
</table>


        </div>

    </div>
<a href="logout.php">Logout</a>
</body>
</html>

