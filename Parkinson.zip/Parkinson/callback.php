<?php

require "init.php";

//$data = fetchData();




?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Researcher</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/css/bootstrap.min.css" 
    integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">

    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>

<link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.0/css/fontawesome.min.css">

</head>
<body>
    <h1 align="center" style="color: red;">Welcome</h1>
    <br>
    <h2 align="center" style="color: blue;">Patient -Therapy -Medicine Details</h2>
    <br>
    <div class="card-body">
        <div class="table-responsive">

        <table class="table table-bordered" ;" style="background-color:pink ;">
  <thead >
    <tr >
      <th scope="col">Patient Name</th>
      <th scope="col">Email</th>
      <th scope="col">Therapy</th>
      <th scope="col">Medicine</th>
      <th scope="col">Dosage</th>
    </tr>
  </thead>
  <tbody>
    <?php

    $host="localhost";
    $user="root";
    $password="";
 $db="patient";
  
     
    $con=mysqli_connect($host,$user,$password,$db);

    if($con===false)
{
	die("connection error");
}


     $sql="select user.username,user.email,therapy_list.thername,medicine.name,therapy_list.Dosage FROM user inner join therapy on user.userID=therapy.user_IDpatient inner join therapy_list on therapy.TherapyList_IDtherapylist = therapy_list.therapy_listID inner join medicine on therapy.User_IDmed=medicine.medicineID WHERE user.Role_IDrole='1'; ";
    $query1=mysqli_query($con,$sql);
     //$row=mysqli_fetch_array($query1);
     

    while ($row=mysqli_fetch_array($query1))
    {
    ?>
    <tr>
        
        <td> <?php echo  $row['username'];?>  </td>
        <td> <?php echo $row['email'];?>  </td>
        <td> <?php echo $row['thername'];?>  </td>
        <td> <?php echo $row['name'];?>  </td>
        <td> <?php echo $row['Dosage'];?>  </td>

       
    </tr>
    <?php
    }
    ?>
  </tbody>
</table>

        </div>

    </div>
    <div>
   <table align="right"  width="300px" border="2px" style="color:blue ;" >
    <thead>
    <tr >
      <th scope="col">Test Type</th>
      <th scope="col">Test Data</th>  
       
    </tr>
    </thead>
    <tbody>

      <?php
      $test_query=" select 	test_type, DataURL from test_session ";
      $t_query=mysqli_query($con,$test_query);
      while ($dat=mysqli_fetch_array($t_query))
      {
      ?>
        <tr>
        
        <td> <?php echo  $dat['test_type'];?>  </td>
        <?php
        $abc=$dat['DataURL'];
      ?>
        <td><a href="http://localhost:3000/<?php echo $abc; ?>.csv "> <?php echo  $dat['DataURL'];?> </a> </td>
        </tr>
        <?php
      }
      ?>
      
    </tbody>
    </table>
    </div>
    <h3 align="center"><a href="gitlogout.php">Log Out</a></h3>
    <br>
    <br>
    <!-- start sw-rss-feed code --> 
<script type="text/javascript"> 
<!-- 
rssfeed_url = new Array(); 
rssfeed_url[0]="https://www.news-medical.net/tag/feed/Parkinsons-Disease.aspx";  
rssfeed_frame_width="800"; 
rssfeed_frame_height="600"; 
rssfeed_scroll="on"; 
rssfeed_scroll_step="6"; 
rssfeed_scroll_bar="off"; 
rssfeed_target="_blank"; 
rssfeed_font_size="12"; 
rssfeed_font_face=""; 
rssfeed_border="on"; 
rssfeed_css_url="https://feed.surfing-waves.com/css/style6.css"; 
rssfeed_title="on"; 
rssfeed_title_name=""; 
rssfeed_title_bgcolor="#3366ff"; 
rssfeed_title_color="#fff"; 
rssfeed_title_bgimage=""; 
rssfeed_footer="off"; 
rssfeed_footer_name="rss feed"; 
rssfeed_footer_bgcolor="#fff"; 
rssfeed_footer_color="#333"; 
rssfeed_footer_bgimage=""; 
rssfeed_item_title_length="50"; 
rssfeed_item_title_color="#666"; 
rssfeed_item_bgcolor="#fff"; 
rssfeed_item_bgimage=""; 
rssfeed_item_border_bottom="on"; 
rssfeed_item_source_icon="off"; 
rssfeed_item_date="off"; 
rssfeed_item_description="on"; 
rssfeed_item_description_length="120"; 
rssfeed_item_description_color="#666"; 
rssfeed_item_description_link_color="#333"; 
rssfeed_item_description_tag="off"; 
rssfeed_no_items="0"; 
rssfeed_cache = "1cc870bd9576ce4dfc98cb44e732946a"; 
//--> 
</script> 
<script type="text/javascript" src="//feed.surfing-waves.com/js/rss-feed.js"></script> 
<!-- The link below helps keep this service FREE, and helps other people find the SW widget. Please be cool and keep it! Thanks. --> 
<div style="color:#ccc;font-size:10px; text-align:right; width:800px;">powered by <a href="https://surfing-waves.com" rel="noopener" target="_blank" style="color:#ccc;">Surfing Waves</a></div> 
<!-- end sw-rss-feed code -->
   
   </body>
</html>




