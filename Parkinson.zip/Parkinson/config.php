<?php
    // your app consumer key
    define( 'CONSUMER_KEY', 'ajBUXOWhwnv7ObuPkNdUAmxgw' ); 

    // your app consumer secret
    define( 'CONSUMER_SECRET', 'knhdciyMWWxdnhVgvTc9Ur4aXN3MAZVBCIdReBHKhMOLygtnW9' );

    // your app callback url
    define( 'OAUTH_CALLBACK', 'http://localhost:3000/physician.php/' );