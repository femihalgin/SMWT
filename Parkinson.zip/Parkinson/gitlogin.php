<?php


require "init.php";

//this will redirect user to github authorization page
goToAuthUrl();


//if no redirection occur then following shows.
echo "operation failed.";

?>



