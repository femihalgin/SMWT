<?php

function goToAuthUrl()
{
    $client_id = "8900efcf915a6d45ea25";
    $redirect_url = "http://localhost:3000/callback.php";
    if ($_SERVER['REQUEST_METHOD'] == 'GET') {
        $url = 'https://github.com/login/oauth/authorize?client_id='. $client_id. "&redirect_url=".$redirect_url."&scope=user";
        header("location: $url");
    }
}


?>

