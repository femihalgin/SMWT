<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>

<center>

	<h1>Login Form</h1>
	<br><br><br><br>
	<div style="background-color: pink; width: 500px;">
		<br><br>
        <div>
            <label>username</label>
        </div>
	<br><br>

        <div>
            <label>password</label>
           
        </div>
	<br><br>

        

	<br><br>
 </div>
</center>

</body>
</html>
