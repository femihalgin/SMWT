<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=chrome">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <center>
    <h1>Welcome</h1>
    
    <h1>Here we are providing some exercises. Go through it</h1>\
    <br>
    <br>
    
    
<iframe width="400" height="200" src="https://www.youtube.com/embed/WRyPQO_u_qE" title="YouTube video player" frameborder="0"
     allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
    
     
     <iframe width="400" height="200" src="https://www.youtube.com/embed/DX0IVHHlCC0" title="YouTube video player" frameborder="0"
      allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
   
      <iframe width="400" height="200" src="https://www.youtube.com/embed/wkDiOCIX_xA" title="YouTube video player" frameborder="0" allow="accelerometer; 
      autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
      <iframe width="400" height="200" src="https://www.youtube.com/embed/KiyHrpnWmVY" title="YouTube video player" frameborder="0" 
      allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
      <iframe width="400" height="200" src="https://www.youtube.com/embed/recpcNfHFHs" title="YouTube video player" frameborder="0" 
      allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
      <iframe width="400" height="200" src="https://www.youtube.com/embed/8AvLz59Yk_Y" title="YouTube video player" frameborder="0"
       allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
       <iframe width="400" height="200" src="https://www.youtube.com/embed/pgtGOgVIhqc" title="YouTube video player" frameborder="0" 
        allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
        <iframe width="400" height="200" src="https://www.youtube.com/embed/AZV3_NfcpVs" title="YouTube video player" frameborder="0" 
            allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
            <br>
            <br>
            <label style="font-size: 25px; ">
            <br>
            <br>
            <a href="patientlogout.php">Log Out</a>
            </label>
 </center>
</body>
</html>